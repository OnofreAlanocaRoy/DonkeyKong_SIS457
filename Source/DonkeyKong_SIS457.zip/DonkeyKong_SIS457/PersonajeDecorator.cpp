// Fill out your copyright notice in the Description page of Project Settings.


#include "PersonajeDecorator.h"

// Add default functionality here for any IPersonajeDecorator functions that are not pure virtual.
