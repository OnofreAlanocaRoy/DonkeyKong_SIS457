// ArmaDecorator.cpp
#include "ArmaDecorator.h"
#include "Engine/Engine.h"

UArmaDecorator::UArmaDecorator()
{
	// Configuraci�n inicial
}

void UArmaDecorator::Equipar()
{
	// L�gica para no hacer nada relacionado con armaduras si la espada est� equipada
}

void UArmaDecorator::UsarArma()
{
	// L�gica para usar un arma
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("�Arma usada!"));
	}
}
