// ArmaDecorator.h
#pragma once

#include "CoreMinimal.h"
#include "PersonajeDecorator.h"
#include "ArmaDecorator.generated.h"

UCLASS(Blueprintable)
class DONKEYKONG_SIS457_API UArmaDecorator : public UObject, public IPersonajeDecorator
{
	GENERATED_BODY()

public:
	UArmaDecorator();

	virtual void Equipar() override;

	virtual void UsarArma() override;
};

