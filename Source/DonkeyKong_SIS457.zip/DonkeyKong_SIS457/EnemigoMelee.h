#pragma once

#include "CoreMinimal.h"
#include "Enemigo.h"
#include "EnemigoMelee.generated.h"

UCLASS()
class DONKEYKONG_SIS457_API AEnemigoMelee : public AEnemigo {
    GENERATED_BODY()

public:
   /* AEnemigoMelee();*/

 /*   virtual void Pelear() override;
    virtual int ObtenerDanio() override;
    virtual void Morir() override;*/

};
