#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Barril.h"  // Como ejemplo de un �tem
#include "Enemigo.h" // Como ejemplo de un enemigo
#include "GameFacade.generated.h"

UCLASS()
class DONKEYKONG_SIS457_API AGameFacade : public AActor
{
    GENERATED_BODY()

public:
    AGameFacade();

    // Funci�n p�blica que controla la l�gica de generaci�n de barriles
    void IniciarGeneracionBarriles();

    // Funci�n p�blica para generar barril manualmente
    void GenerarBarrilConLimite();

protected:
    // Propiedades editables desde el editor de Unreal
    UPROPERTY(EditAnywhere, Category = "Barril")
    int32 NumeroMaximoBarriles = 5;

    UPROPERTY(EditAnywhere, Category = "Barril")
    TSubclassOf<class ABarril> BarrilClass;

    // Contador interno de barriles generados
    int32 ContadorBarriles = 0;

    // Timer que controla la generaci�n peri�dica de barriles
    FTimerHandle SpawnBarrilTimerHandle;

private:
    // M�todo que maneja la creaci�n de barriles y aumenta el contador
    void CrearBarril();
};
