#include "GameFacade.h"
#include "Barril.h"
#include "Kismet/GameplayStatics.h"

AGameFacade::AGameFacade()
{
    PrimaryActorTick.bCanEverTick = true; // Habilita la ejecuci�n de Tick si lo necesitas
}

void AGameFacade::IniciarGeneracionBarriles()
{
    // Iniciar un temporizador para generar barriles de forma peri�dica
    GetWorld()->GetTimerManager().SetTimer(SpawnBarrilTimerHandle, this, &AGameFacade::GenerarBarrilConLimite, 1.0f, true);
}

void AGameFacade::GenerarBarrilConLimite()
{
    if (ContadorBarriles < NumeroMaximoBarriles && BarrilClass)
    {
        CrearBarril();  // Crear un barril

        if (ContadorBarriles >= NumeroMaximoBarriles)
        {
            // Detener el temporizador cuando se alcance el l�mite
            GetWorld()->GetTimerManager().ClearTimer(SpawnBarrilTimerHandle);
        }
    }
}

void AGameFacade::CrearBarril()
{
    // Establecer la ubicaci�n y rotaci�n del barril
    FTransform SpawnLocationBarril;
    SpawnLocationBarril.SetLocation(FVector(1160.0f, 900.0f, 860.0f));  // Ajusta seg�n sea necesario
    SpawnLocationBarril.SetRotation(FQuat(FRotator(90.0f, 0.0f, 0.0f)));

    // Crear el barril en el mundo
    ABarril* NuevoBarril = GetWorld()->SpawnActor<ABarril>(BarrilClass, SpawnLocationBarril);

    if (NuevoBarril)
    {
        ContadorBarriles++;  // Incrementar el contador de barriles generados
    }
}
