#include "EnemigoProyectil.h"
//
//void AEnemigoProyectil::Pelear() {
//    Super::Pelear();
//    UE_LOG(LogTemp, Warning, TEXT("El enemigo Proyectil dispara un proyectil"));
//}
//
//int AEnemigoProyectil::ObtenerDanio() {
//    return DanioBase + 95;
//}
//
//void AEnemigoProyectil::Morir() {
//    Super::Morir();
//    GEngine->AddOnScreenDebugMessage(-1, 15.f, FColor::Yellow, TEXT("El enemigo Proyectil se desintegra"));
//}

