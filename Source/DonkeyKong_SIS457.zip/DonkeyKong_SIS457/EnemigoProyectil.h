#pragma once

#include "CoreMinimal.h"
#include "Enemigo.h"
#include "EnemigoProyectil.generated.h"

UCLASS()
class DONKEYKONG_SIS457_API AEnemigoProyectil : public AEnemigo {
    GENERATED_BODY()

public:
    //virtual void Pelear() override;
    //virtual int ObtenerDanio() override;
    //virtual void Morir() override;
};
