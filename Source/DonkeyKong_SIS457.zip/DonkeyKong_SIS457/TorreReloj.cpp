#include "TorreReloj.h"
#include "Engine/World.h"
#include "TimerManager.h"

ATorreReloj::ATorreReloj()
{
	PrimaryActorTick.bCanEverTick = true;
}

void ATorreReloj::BeginPlay()
{
	Super::BeginPlay();
	IniciarTemporizador();  // Inicia el temporizador al comenzar el juego
}

void ATorreReloj::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ATorreReloj::IniciarTemporizador()
{
	// El reloj va a notificar cada minuto (15 segundos)
	GetWorld()->GetTimerManager().SetTimer(TimerHandle, this, &ATorreReloj::RelojTick, 15.0f, true, 0.0f);
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Red, TEXT("El reloj va a notificar cada minuto (15 segundos)"));
	}
}
void ATorreReloj::RelojTick()
{
	// Notificar a los suscriptores cada vez que suena el reloj
	Notificar();
	// Mostrar mensaje en pantalla
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Yellow, TEXT("Torre Reloj: Notificaci�n enviada a los suscriptores."));
	}
}

void ATorreReloj::AnadirSuscriptor(AActor* Suscriptor)
{
	if (Suscriptor && !Suscriptores.Contains(Suscriptor))
	{
		Suscriptores.Add(Suscriptor);
	}
}

void ATorreReloj::EliminarSuscriptor(AActor* Suscriptor)
{
	Suscriptores.Remove(Suscriptor);
}

void ATorreReloj::Notificar()
{
	for (AActor* Suscriptor : Suscriptores)
	{
		// Llamar la funci�n de notificaci�n en el observador
		if (Suscriptor)
		{
			// Suponemos que los suscriptores tienen una funci�n llamada "RecibirNotificacion"
			// Si quieres que el jugador o el enemigo hagan algo espec�fico, implementa la l�gica aqu�.
			// Ejemplo: Suscriptor->RecibirNotificacion();
		}
	}
}


