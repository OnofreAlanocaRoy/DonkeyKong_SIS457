// ArmaduraDecorator.cpp
#include "ArmaduraDecorator.h"
#include "Engine/Engine.h"

UArmaduraDecorator::UArmaduraDecorator()
{
	// Configuraciones iniciales
}

void UArmaduraDecorator::Equipar()
{
	// L�gica para equipar armadura
	if (GEngine)
	{
		GEngine->AddOnScreenDebugMessage(-1, 5.f, FColor::Green, TEXT("Armadura equipada"));
	}
}

void UArmaduraDecorator::UsarArma()
{
	// L�gica para no hacer nada relacionado con armas si la armadura est� equipada
	// Podr�a modificarse m�s adelante
}
