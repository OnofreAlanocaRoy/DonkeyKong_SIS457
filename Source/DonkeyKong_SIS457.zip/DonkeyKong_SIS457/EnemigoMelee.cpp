#include "EnemigoMelee.h"

//AEnemigoMelee::AEnemigoMelee() {
//    DanioBase = 10;  // Ajusta el da�o base si es necesario
//}
//
//void AEnemigoMelee::Pelear() {
//    Super::Pelear();
//    UE_LOG(LogTemp, Warning, TEXT("El enemigo Melee lanza un golpe pesado"));
//}
//
//int AEnemigoMelee::ObtenerDanio() {
//    return DanioBase + 5;
//}
//
//void AEnemigoMelee::Morir() {
//    Super::Morir();
//    GEngine->AddOnScreenDebugMessage(-1, 15.f, FColor::Yellow, TEXT("El enemigo Melee se desintegra"));
//}


